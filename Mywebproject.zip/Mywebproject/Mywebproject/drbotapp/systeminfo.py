import platform

print(platform.machine())
print(platform.node())
print(platform.platform(aliased=0, terse=0))
print(platform.processor())
print(platform.release())
print(platform.system())
print(platform.version())
print(platform.uname())