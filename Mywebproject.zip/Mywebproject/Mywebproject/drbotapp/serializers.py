from rest_framework import serializers

from .models import Employee


# class rpaServerserializer(serializers.ModelSerializer):
#     class Meta:
#         model = rpaserverConfig
#         fields = ('applob','appname','appUrl','appAPIkey','param')

class Employeeserializer(serializers.ModelSerializer):

    class Meta:
        model = Employee
        fields = ('Fullname','Emp_No','Mobile')

