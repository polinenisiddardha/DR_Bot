from django.db import models


class tblConfig(models.Model):
    botname = models.CharField(max_length=100)
    botdescription = models.CharField(max_length=100)
    application = models.CharField(max_length=40)


class Contact(models.Model):
    name=models.CharField(max_length=50)
    email=models.CharField(max_length=50)
    phone=models.CharField(max_length=40)
    desc=models.TextField()
    date=models.DateField()



class rparobotconfig(models.Model):
    botname = models.CharField(max_length=100)
    botdesc = models.CharField(max_length=100)
    botServerID = models.CharField(max_length=100)


class rpabotmachine(models.Model):
    machinename = models.CharField(max_length=100)
    machineIP = models.CharField(max_length=100)
    machinedesc = models.CharField(max_length=100)
    RPAServerID = models.CharField(max_length=100)
    NumberofBots = models.IntegerField()

class rpaappinfo(models.Model):
    appname = models.CharField(max_length=100)
    appdesc = models.CharField(max_length=100)
    applob = models.CharField(max_length=100)

class Employee(models.Model):
    Fullname = models.CharField(max_length=50)
    Emp_No = models.CharField(max_length=7)
    Mobile = models.CharField(max_length=10)

class DeviceInfo(models.Model):
    MachineName = models.CharField(max_length=50)
    BotName = models.CharField(max_length=50)
    RAM = models.CharField(max_length=50)
    HardDisk = models.CharField(max_length=50)

class ProcessInfo(models.Model):
    ProcessID = models.CharField(max_length=50)
    ProcessName = models.CharField(max_length=50)
    FileLocation = models.CharField(max_length=50)
    Command = models.CharField(max_length=50)

class rpaserverConfig(models.Model):
    rpalob = models.CharField(max_length=100)
    rpaname = models.CharField(max_length=100)
    rpaUrl = models.URLField(blank=True)
    rpauser = models.CharField(max_length=100)
    rpapassword = models.CharField(max_length=100)

class rpadevice(models.Model):
    hostname = models.CharField(max_length=100)
    Username = models.CharField(max_length=100)
    DeviceID = models.CharField(max_length=50)
    RPAServername = models.CharField(max_length=100)

class scheduleBot (models.Model):
    name  = models.CharField(max_length=100)
    fileId = models.CharField(max_length=30)
    startDate = models.CharField(max_length=10)
    endDate = models.CharField(max_length=10)  
    startTime = models.CharField(max_length=5) 
    description = models.CharField(max_length=10)
    rdpEnabled = models.CharField(max_length=10) 
    scheduleType = models.CharField(max_length=10) 
    repeatEnabled = models.CharField(max_length=10) 
    status = models.CharField(max_length=10)  
    timeZone =  models.CharField(max_length=10)  
    deviceIds = models.ManyToManyField(rpadevice)

class rpafileid (models.Model):
    filename = models.CharField(max_length=100)
    fileID = models.CharField(max_length=30)
    prodVersion = models.BooleanField(default=False)